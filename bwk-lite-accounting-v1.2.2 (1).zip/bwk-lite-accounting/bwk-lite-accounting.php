<?php
/**
 * Plugin Name: BWK Lite Accounting
 * Description: Lightweight accounting: Quotations, Invoices, DO, Transactions, Zakat (MY), product picker (Custom & Woo), View/Print.
 * Version: 1.2.2
 * Author: BinawebKu
 * Text Domain: bwk-lite-accounting
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'BWKLA_VER', '1.2.2' );
define( 'BWKLA_DIR', plugin_dir_path( __FILE__ ) );
define( 'BWKLA_URL', plugin_dir_url( __FILE__ ) );

final class BWK_Lite_Accounting {
    public function __construct(){
        add_action('init', array($this,'register_post_types'));
        add_action('admin_menu', array($this,'register_menu'));
        add_action('admin_enqueue_scripts', array($this,'enqueue_admin_assets'));
        add_action('add_meta_boxes', array($this,'register_metaboxes'));
        add_action('save_post', array($this,'save_all'), 9, 1);
        add_filter('redirect_post_location', array($this,'redirect_after_save'), 999, 2);
        add_action('admin_footer-post.php', array($this,'js_redirect_fallback'));
        add_action('admin_footer-post-new.php', array($this,'js_redirect_fallback'));
        add_filter('post_row_actions', array($this,'row_actions'), 10, 2);
        add_filter('manage_bwk_invoice_posts_columns', array($this,'doc_columns'));
        add_action('manage_bwk_invoice_posts_custom_column', array($this,'doc_columns_content'), 10, 2);
        add_filter('manage_bwk_quote_posts_columns', array($this,'doc_columns'));
        add_action('manage_bwk_quote_posts_custom_column', array($this,'doc_columns_content'), 10, 2);
        add_filter('manage_bwk_do_posts_columns', array($this,'doc_columns'));
        add_action('manage_bwk_do_posts_custom_column', array($this,'doc_columns_content'), 10, 2);

        add_action('wp_ajax_bwkla_quick_save', array($this,'ajax_quick_save'));

        add_shortcode('bwk_invoice', array($this,'sc_invoice'));
        add_shortcode('bwk_quote', array($this,'sc_quote'));
        add_shortcode('bwk_do', array($this,'sc_do'));
    }

    /* ---------- CPTs ---------- */
    public function register_post_types(){
        $supports = array('title');
        $args = array(
            'public'=>false,
            'show_ui'=>true,
            'show_in_menu'=>'bwkla',
            'supports'=>$supports,
            'show_in_rest'=>true
        );

        $inv_labels = array(
            'name' => 'Invoices',
            'singular_name' => 'Invoice',
            'menu_name' => 'Invoices',
            'add_new' => 'Create Invoice',
            'add_new_item' => 'Create Invoice',
            'edit_item' => 'Edit Invoice',
            'new_item' => 'Invoice',
            'view_item' => 'View Invoice',
            'search_items' => 'Search Invoices',
            'name_admin_bar' => 'Invoice'
        );
        $quo_labels = array(
            'name' => 'Quotations',
            'singular_name' => 'Quotation',
            'menu_name' => 'Quotations',
            'add_new' => 'Create Quotation',
            'add_new_item' => 'Create Quotation',
            'edit_item' => 'Edit Quotation',
            'new_item' => 'Quotation',
            'view_item' => 'View Quotation',
            'search_items' => 'Search Quotations',
            'name_admin_bar' => 'Quotation'
        );
        $do_labels = array(
            'name' => 'Delivery Orders',
            'singular_name' => 'Delivery Order',
            'menu_name' => 'Delivery Orders',
            'add_new' => 'Create Delivery Order',
            'add_new_item' => 'Create Delivery Order',
            'edit_item' => 'Edit Delivery Order',
            'new_item' => 'Delivery Order',
            'view_item' => 'View Delivery Order',
            'search_items' => 'Search Delivery Orders',
            'name_admin_bar' => 'Delivery Order'
        );
        $prod_labels = array(
            'name' => 'Products',
            'singular_name' => 'Product',
            'menu_name' => 'Products',
            'add_new' => 'Add Product',
            'add_new_item' => 'Add Product',
            'edit_item' => 'Edit Product',
            'name_admin_bar' => 'Product'
        );

        register_post_type('bwk_invoice', array_merge($args, array('labels'=>$inv_labels,'menu_icon'=>'dashicons-media-spreadsheet')));
        register_post_type('bwk_quote',   array_merge($args, array('labels'=>$quo_labels,'menu_icon'=>'dashicons-media-text')));
        register_post_type('bwk_do',      array_merge($args, array('labels'=>$do_labels,'menu_icon'=>'dashicons-clipboard')));
        register_post_type('bwk_txn',     array_merge($args, array('labels'=>array('name'=>'Transactions','singular_name'=>'Transaction'),'menu_icon'=>'dashicons-chart-line')));
        register_post_type('bwk_product', array_merge($args, array('labels'=>$prod_labels,'menu_icon'=>'dashicons-products')));
    }

    public function register_menu(){
        // Make REPORTS the main/top item
        add_menu_page('Reports — Lite Accounting','Lite Accounting','manage_options','bwkla', array($this,'reports'),'dashicons-calculator',25);
        add_submenu_page('bwkla','Reports','Reports','manage_options','bwkla', array($this,'reports'));
        add_submenu_page('bwkla','Dashboard','Dashboard','manage_options','bwkla-dashboard', array($this,'dashboard'));
        add_submenu_page('bwkla','Zakat','Zakat','manage_options','bwkla-zakat', array($this,'zakat'));
        add_submenu_page('bwkla','Woo Sync','Woo Sync','manage_options','bwkla-wc', array($this,'woo'));
        add_submenu_page('bwkla','View','View','edit_posts','bwkla-view', array($this,'view_screen'));
        add_submenu_page('bwkla','Settings','Settings','manage_options','bwkla-settings', array($this,'settings'));
    }

    public function enqueue_admin_assets($hook){
        $screen = get_current_screen();
        if ( $screen && in_array($screen->post_type, array('bwk_invoice','bwk_quote','bwk_do','bwk_txn','bwk_product'),true) ){
            wp_enqueue_style('bwkla-admin', BWKLA_URL.'assets/css/admin.css', array(), BWKLA_VER);
            wp_enqueue_script('bwkla-admin', BWKLA_URL.'assets/js/admin.js', array('jquery'), BWKLA_VER, true);
        }
        if ( false !== strpos($hook,'bwkla') ){
            wp_enqueue_style('bwkla-admin', BWKLA_URL.'assets/css/admin.css', array(), BWKLA_VER);
            wp_enqueue_script('bwkla-admin', BWKLA_URL.'assets/js/admin.js', array('jquery'), BWKLA_VER, true);
        }
    }

    /* ---------- UI ---------- */
    public function register_metaboxes(){
        foreach(['bwk_invoice','bwk_quote','bwk_do'] as $pt){
            add_meta_box('bwkla_doc_details','Document Details', array($this,'mb_doc_details'), $pt, 'normal', 'high');
            add_meta_box('bwkla_items','Line Items', array($this,'mb_items'), $pt, 'normal', 'default');
        }
    }

    private function get_opt($key,$def=''){ $v = get_option($key,$def); return $v===''?$def:$v; }
    private function get_meta($post_id,$key,$def=''){ $v = get_post_meta($post_id,$key,true); return $v===''?$def:$v; }
    private function doc_prefix($type){ return $type==='bwk_invoice'?'INV':($type==='bwk_quote'?'QUO':($type==='bwk_do'?'DO':'DOC')); }
    private function next_number($type){
        global $wpdb; $prefix=$this->doc_prefix($type).'-'.current_time('Ymd').'-'; $like=$prefix.'%';
        $q=$wpdb->get_var($wpdb->prepare("SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key=%s AND meta_value LIKE %s ORDER BY meta_value DESC LIMIT 1",'_bwk_number',$like));
        $i=1; if($q){ $i=intval(substr($q,-3))+1; } return $prefix.str_pad($i,3,'0',STR_PAD_LEFT);
    }

    public function mb_doc_details($post){
        $n = $this->get_meta($post->ID,'_bwk_number',''); if (!$n) $n = $this->next_number($post->post_type);
        $date=$this->get_meta($post->ID,'_bwk_date',current_time('Y-m-d'));
        $due=$this->get_meta($post->ID,'_bwk_due','');
        $status=$this->get_meta($post->ID,'_bwk_status','draft');
        $customer=$this->get_meta($post->ID,'_bwk_customer','');
        $company=$this->get_meta($post->ID,'_bwk_company','');
        $phone=$this->get_meta($post->ID,'_bwk_phone','');
        $email=$this->get_meta($post->ID,'_bwk_email','');
        $address=$this->get_meta($post->ID,'_bwk_address','');
        $notes=$this->get_meta($post->ID,'_bwk_notes','');
        wp_nonce_field('bwkla_save','bwkla_nonce');
        ?>
        <div class="bwk-grid">
            <div><label>Number</label><input type="text" name="bwk[number]" value="<?php echo esc_attr($n); ?>" /></div>
            <div><label>Date</label><input type="date" name="bwk[date]" value="<?php echo esc_attr($date); ?>" /></div>
            <div><label>Due</label><input type="date" name="bwk[due]" value="<?php echo esc_attr($due); ?>" /></div>
            <div><label>Status</label><select name="bwk[status]"><?php foreach(['draft'=>'Draft','sent'=>'Sent','partial'=>'Partial','paid'=>'Paid','void'=>'Void'] as $k=>$v) printf('<option value="%s" %s>%s</option>',esc_attr($k),selected($status,$k,false),esc_html($v)); ?></select></div>
            <div class="bwk-col2"><label>Customer</label><input type="text" name="bwk[customer]" value="<?php echo esc_attr($customer); ?>" /></div>
            <div><label>Company</label><input type="text" name="bwk[company]" value="<?php echo esc_attr($company); ?>" /></div>
            <div><label>Phone</label><input type="text" name="bwk[phone]" value="<?php echo esc_attr($phone); ?>" /></div>
            <div><label>Email</label><input type="email" name="bwk[email]" value="<?php echo esc_attr($email); ?>" /></div>
            <div class="bwk-col2"><label>Address</label><textarea name="bwk[address]" rows="3"><?php echo esc_textarea($address); ?></textarea></div>
            <div class="bwk-col2"><label>Remarks</label><textarea name="bwk[notes]" rows="3"><?php echo esc_textarea($notes); ?></textarea></div>
        </div>
        <?php
    }

    public function mb_items($post){
        $currency=$this->get_opt('bwkla_currency','MYR');
        $items=$this->get_meta($post->ID,'_bwk_items',array()); if(!is_array($items)) $items=array();
        $subtotal=(float)$this->get_meta($post->ID,'_bwk_subtotal',0);
        $discount=(float)$this->get_meta($post->ID,'_bwk_discount',0);
        $tax_rate=(float)$this->get_meta($post->ID,'_bwk_tax_rate',0);
        $shipping=(float)$this->get_meta($post->ID,'_bwk_shipping',0);
        $grand=(float)$this->get_meta($post->ID,'_bwk_grand',0);

        $options=array();
        $pp=get_posts(array('post_type'=>'bwk_product','posts_per_page'=>100,'post_status'=>'publish'));
        foreach($pp as $p){ $sku=get_post_meta($p->ID,'_bwk_sku',true); $price=(float)get_post_meta($p->ID,'_bwk_price',true); $options[]='custom#'.$p->ID.' | '.($sku?$sku.' | ':'').$p->post_title.' | '.number_format($price,2,'.',''); }
        if ( class_exists('WooCommerce') && function_exists('wc_get_products') ){
            $wc = wc_get_products(array('status'=>'publish','limit'=>100,'orderby'=>'date','order'=>'DESC'));
            foreach($wc as $prod){ $sku=$prod->get_sku(); $price=(float)$prod->get_price(); $options[]='wc#'.$prod->get_id().' | '.($sku?$sku.' | ':'').$prod->get_name().' | '.number_format($price,2,'.',''); }
        }
        ?>
        <div class="bwk-items-wrap" data-currency="<?php echo esc_attr($currency); ?>">
            <p class="no-print"><button type="button" class="button" id="bwk-quick-save" data-postid="<?php echo intval($post->ID); ?>" data-nonce="<?php echo wp_create_nonce('bwkla_quick_save'); ?>">Save (Draft)</button> <span class="bwk-save-state"></span></p>
            <datalist id="bwk-prodlist"><?php foreach($options as $o) echo '<option value="'.esc_attr($o).'"></option>'; ?></datalist>
            <table class="bwk-items">
                <thead><tr><th style="width:42%">Item <small class="muted">Search list or type</small></th><th style="width:12%">Qty</th><th style="width:18%">Unit</th><th style="width:18%">Total</th><th></th></tr></thead>
                <tbody>
                <?php if(empty($items)): $i=0; ?>
                    <tr>
                        <td>
                            <input type="text" name="bwk_items[0][name]" placeholder="Item name" />
                            <div class="bwk-pick"><input name="bwk_items[0][lookup]" list="bwk-prodlist" class="bwk-lookup" placeholder="Search product (SKU/Name)" /><button class="button button-small bwk-fill">Fill</button></div>
                        </td>
                        <td><input type="number" step="0.01" name="bwk_items[0][qty]" value="1" /></td>
                        <td><input type="number" step="0.01" name="bwk_items[0][price]" value="0" /></td>
                        <td><input type="number" step="0.01" name="bwk_items[0][total]" value="0" readonly /></td>
                        <td><button class="button bwk-del">×</button></td>
                    </tr>
                <?php else: foreach($items as $i=>$row): ?>
                    <tr>
                        <td>
                            <input type="text" name="bwk_items[<?php echo $i; ?>][name]" value="<?php echo esc_attr($row['name']??''); ?>" />
                            <div class="bwk-pick"><input name="bwk_items[<?php echo $i; ?>][lookup]" list="bwk-prodlist" class="bwk-lookup" placeholder="Search product (SKU/Name)" /><button class="button button-small bwk-fill">Fill</button></div>
                        </td>
                        <td><input type="number" step="0.01" name="bwk_items[<?php echo $i; ?>][qty]" value="<?php echo esc_attr($row['qty']??1); ?>" /></td>
                        <td><input type="number" step="0.01" name="bwk_items[<?php echo $i; ?>][price]" value="<?php echo esc_attr($row['price']??0); ?>" /></td>
                        <td><input type="number" step="0.01" name="bwk_items[<?php echo $i; ?>][total]" value="<?php echo esc_attr($row['total']??0); ?>" readonly /></td>
                        <td><button class="button bwk-del">×</button></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            <p><button class="button button-primary bwk-add">+ Add Item</button></p>
            <div class="bwk-totals">
                <div><label>Subtotal</label><input type="number" step="0.01" name="bwk_totals[subtotal]" value="<?php echo esc_attr($subtotal); ?>" readonly /></div>
                <div><label>Discount</label><input type="number" step="0.01" name="bwk_totals[discount]" value="<?php echo esc_attr($discount); ?>" /></div>
                <div><label>Tax %</label><input type="number" step="0.01" name="bwk_totals[tax_rate]" value="<?php echo esc_attr($tax_rate); ?>" /></div>
                <div><label>Shipping</label><input type="number" step="0.01" name="bwk_totals[shipping]" value="<?php echo esc_attr($shipping); ?>" /></div>
                <div class="bwk-grand"><label>Grand</label><input type="number" step="0.01" name="bwk_totals[grand]" value="<?php echo esc_attr($grand); ?>" readonly /></div>
            </div>
        </div>
        <?php
    }

    /* ---------- SAVE ---------- */
    private function parse_lookup($val){
        $parts = array_map('trim', explode('|', (string)$val));
        $name = ''; $price = 0;
        if (count($parts) >= 4){ $name=$parts[2]; $price=(float)$parts[3]; }
        elseif (count($parts) === 3){
            $maybe = str_replace(array('MYR','RM',' '),'',$parts[2]);
            if (is_numeric($maybe)){ $name=$parts[1]; $price=(float)$maybe; } else { $name=$parts[2]; }
        } elseif (count($parts) === 2){ $name=$parts[1]; }
        return array($name,$price);
    }

    private function compute_and_save_items($post_id, $items, $totals){
        $clean = array(); $subtotal = 0.0;
        $rows = array_values(is_array($items)?$items:array()); // normalize
        foreach($rows as $row){
            $name = isset($row['name']) ? sanitize_text_field($row['name']) : '';
            $lookup = isset($row['lookup']) ? sanitize_text_field($row['lookup']) : '';
            if ($name==='' && $lookup!==''){ list($ln,$lp) = $this->parse_lookup($lookup); if($ln) $name=$ln; if(empty($row['price']) && $lp) $row['price']=$lp; if(empty($row['qty'])) $row['qty']=1; }
            if ($name==='') continue;
            $qty = (float)($row['qty'] ?? 1);
            $price = (float)($row['price'] ?? 0);
            $total = (float)($row['total'] ?? ($qty*$price));
            $subtotal += $total;
            $clean[] = array('name'=>$name,'qty'=>$qty,'price'=>$price,'total'=>$total);
        }
        $discount = (float)($totals['discount'] ?? 0);
        $tax_rate = (float)($totals['tax_rate'] ?? 0);
        $shipping = (float)($totals['shipping'] ?? 0);
        $tax_amount = (($subtotal - $discount) * $tax_rate) / 100;
        $grand = $subtotal - $discount + $tax_amount + $shipping;

        update_post_meta($post_id,'_bwk_items',$clean);
        update_post_meta($post_id,'_bwk_subtotal',$subtotal);
        update_post_meta($post_id,'_bwk_discount',$discount);
        update_post_meta($post_id,'_bwk_tax_rate',$tax_rate);
        update_post_meta($post_id,'_bwk_shipping',$shipping);
        update_post_meta($post_id,'_bwk_grand',$grand);
    }

    public function save_all($post_id){
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
        if (wp_is_post_revision($post_id)) return;
        $post = get_post($post_id); if(!$post) return;

        if ( in_array($post->post_type, array('bwk_invoice','bwk_quote','bwk_do'), true) ){
            $f = isset($_POST['bwk']) ? (array)$_POST['bwk'] : array();
            $number = sanitize_text_field($f['number'] ?? '');
            if (!$number) $number = $this->next_number($post->post_type);
            update_post_meta($post_id,'_bwk_number',$number);
            update_post_meta($post_id,'_bwk_date',sanitize_text_field($f['date'] ?? current_time('Y-m-d')));
            update_post_meta($post_id,'_bwk_due',sanitize_text_field($f['due'] ?? ''));
            update_post_meta($post_id,'_bwk_status',sanitize_text_field($f['status'] ?? 'draft'));
            update_post_meta($post_id,'_bwk_customer',sanitize_text_field($f['customer'] ?? ''));
            update_post_meta($post_id,'_bwk_company',sanitize_text_field($f['company'] ?? ''));
            update_post_meta($post_id,'_bwk_phone',sanitize_text_field($f['phone'] ?? ''));
            update_post_meta($post_id,'_bwk_email',sanitize_email($f['email'] ?? ''));
            update_post_meta($post_id,'_bwk_address',wp_kses_post($f['address'] ?? ''));
            update_post_meta($post_id,'_bwk_notes',wp_kses_post($f['notes'] ?? ''));
            $items = isset($_POST['bwk_items']) ? (array)$_POST['bwk_items'] : array();
            $totals = isset($_POST['bwk_totals']) ? (array)$_POST['bwk_totals'] : array();
            $this->compute_and_save_items($post_id,$items,$totals);
        }
    }

    public function ajax_quick_save(){
        check_ajax_referer('bwkla_quick_save');
        if ( ! current_user_can('edit_posts') ) wp_send_json_error(array('message'=>'no-permission'));
        $post_id = intval($_POST['post_id'] ?? 0); if(!$post_id) wp_send_json_error(array('message'=>'no-id'));
        $this->save_all($post_id);
        $num = get_post_meta($post_id,'_bwk_number',true);
        wp_send_json_success(array('number'=>$num));
    }

    public function redirect_after_save($location,$post_id){
        $post = get_post($post_id); if(!$post) return $location;
        if ( in_array($post->post_type, array('bwk_invoice','bwk_quote','bwk_do'), true) ){
            return admin_url('admin.php?page=bwkla-view&post_id='.$post_id);
        }
        return $location;
    }

    public function js_redirect_fallback(){
        $screen = get_current_screen();
        if (!$screen || !in_array($screen->post_type, array('bwk_invoice','bwk_quote','bwk_do'), true)) return;
        $post_id = isset($_GET['post']) ? intval($_GET['post']) : 0;
        ?>
        <script>
        (function(){
            var form = document.querySelector('form#post');
            if (!form) return;
            form.addEventListener('submit', function(){
                var idField = document.getElementById('post_ID');
                if (idField && idField.value) {
                    try { sessionStorage.setItem('bwkla_view_for', idField.value); } catch(e){}
                }
            }, {capture:true});
            try {
                var pid = sessionStorage.getItem('bwkla_view_for');
                if (pid) {
                    sessionStorage.removeItem('bwkla_view_for');
                    var url = '<?php echo esc_js( admin_url('admin.php?page=bwkla-view&post_id=') ); ?>' + pid;
                    if (location.href.indexOf('page=bwkla-view') === -1) location.replace(url);
                }
            } catch(e){}
        })();
        </script>
        <?php
    }

    /* ---------- Columns & Row actions ---------- */
    public function doc_columns($cols){ return array('cb'=>$cols['cb']??'', 'title'=>'Title', 'bwk_number'=>'Number', 'bwk_customer'=>'Customer', 'bwk_total'=>'Total', 'bwk_status'=>'Status', 'bwk_view'=>'View', 'date'=>'Date'); }
    public function doc_columns_content($col,$post_id){
        switch($col){
            case 'bwk_number': echo esc_html(get_post_meta($post_id,'_bwk_number',true)); break;
            case 'bwk_customer': echo esc_html(get_post_meta($post_id,'_bwk_customer',true)); break;
            case 'bwk_total': $v=(float)get_post_meta($post_id,'_bwk_grand',true); echo esc_html($this->get_opt('bwkla_currency','MYR')).' '.number_format_i18n($v,2); break;
            case 'bwk_status': echo esc_html(get_post_meta($post_id,'_bwk_status',true)); break;
            case 'bwk_view': $url=admin_url('admin.php?page=bwkla-view&post_id='.$post_id); echo '<a class="button" href="'.esc_url($url).'">View</a>'; break;
        }
    }
    public function row_actions($a,$post){ if(in_array($post->post_type,array('bwk_invoice','bwk_quote','bwk_do'),true)){ $a['bwkla_view']='<a href="'.esc_url(admin_url('admin.php?page=bwkla-view&post_id='.$post->ID)).'">View/Print</a>'; } return $a; }

    /* ---------- Pages ---------- */
    public function dashboard(){ echo '<div class="wrap bwkla"><h1>Dashboard</h1><p>Quick links: <a class="button button-primary" href="'.esc_url(admin_url('edit.php?post_type=bwk_quote')).'">Create Quotation</a> <a class="button button-primary" href="'.esc_url(admin_url('edit.php?post_type=bwk_invoice')).'">Create Invoice</a> <a class="button button-primary" href="'.esc_url(admin_url('edit.php?post_type=bwk_do')).'">Create Delivery Order</a></p></div>'; }
    public function reports(){ echo '<div class="wrap bwkla"><h1>Reports</h1><p>Summary & P/L (basic).</p></div>'; }
    public function zakat(){ echo '<div class="wrap bwkla"><h1>Zakat</h1><p>2.5% calculator — coming back shortly.</p></div>'; }
    public function woo(){ echo '<div class="wrap bwkla"><h1>Woo Sync</h1><p>Sync orders to ledger (coming back).</p></div>'; }
    public function settings(){
        if (isset($_POST['bwkla_save']) && check_admin_referer('bwkla_settings')){
            $data = array(
                'name'=>sanitize_text_field($_POST['company']['name']??''),
                'address'=>sanitize_textarea_field($_POST['company']['address']??''),
                'phone'=>sanitize_text_field($_POST['company']['phone']??''),
                'email'=>sanitize_email($_POST['company']['email']??''),
                'logo'=>esc_url_raw($_POST['company']['logo']??'')
            );
            update_option('bwkla_company',$data);
            update_option('bwkla_currency',sanitize_text_field($_POST['currency']??'MYR'));
            echo '<div class="updated notice"><p>Settings saved.</p></div>';
        }
        $company = get_option('bwkla_company',array());
        $currency = $this->get_opt('bwkla_currency','MYR');
        echo '<div class="wrap bwkla"><h1>Settings</h1><form method="post">';
        wp_nonce_field('bwkla_settings');
        echo '<h2 class="title">Company</h2><div class="bwk-grid bwk-col2">';
        printf('<div class="bwk-col2"><label>Logo URL</label><input type="text" name="company[logo]" value="%s" /></div>', esc_attr($company['logo']??''));
        printf('<div class="bwk-col2"><label>Name</label><input type="text" name="company[name]" value="%s" /></div>', esc_attr($company['name']??''));
        printf('<div class="bwk-col2"><label>Address</label><textarea name="company[address]" rows="3">%s</textarea></div>', esc_textarea($company['address']??''));
        printf('<div><label>Phone</label><input type="text" name="company[phone]" value="%s" /></div>', esc_attr($company['phone']??''));
        printf('<div><label>Email</label><input type="email" name="company[email]" value="%s" /></div>', esc_attr($company['email']??''));
        echo '</div><h2 class="title">General</h2>';
        printf('<p><label>Currency code</label> <input type="text" name="currency" value="%s" /></p>', esc_attr($currency));
        submit_button('Save Settings','primary','bwkla_save');
        echo '</form></div>';
    }

    public function view_screen(){
        $post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : 0;
        $post = get_post($post_id);
        if(!$post || ! in_array($post->post_type, array('bwk_invoice','bwk_quote','bwk_do'),true)){ echo '<div class="wrap"><h1>Invalid document</h1></div>'; return; }
        echo $this->render_doc($post_id,$post->post_type,true);
    }

    private function render_doc($post_id,$type,$wrap=false){
        $post = get_post($post_id); if(!$post) return '';
        $company = get_option('bwkla_company',array());
        $currency = $this->get_opt('bwkla_currency','MYR');
        $number=get_post_meta($post_id,'_bwk_number',true);
        $date=get_post_meta($post_id,'_bwk_date',true);
        $due=get_post_meta($post_id,'_bwk_due',true);
        $customer=get_post_meta($post_id,'_bwk_customer',true);
        $company_c=get_post_meta($post_id,'_bwk_company',true);
        $phone=get_post_meta($post_id,'_bwk_phone',true);
        $email=get_post_meta($post_id,'_bwk_email',true);
        $address=get_post_meta($post_id,'_bwk_address',true);
        $notes=get_post_meta($post_id,'_bwk_notes',true);
        $items=get_post_meta($post_id,'_bwk_items',true);
        $subtotal=(float)get_post_meta($post_id,'_bwk_subtotal',true);
        $discount=(float)get_post_meta($post_id,'_bwk_discount',true);
        $tax_rate=(float)get_post_meta($post_id,'_bwk_tax_rate',true);
        $shipping=(float)get_post_meta($post_id,'_bwk_shipping',true);
        $grand=(float)get_post_meta($post_id,'_bwk_grand',true);
        ob_start();
        include BWKLA_DIR.'templates/doc-view.php';
        $html = ob_get_clean();
        if($wrap) return '<div class="wrap bwkla"><h1>'.($type==='bwk_invoice'?'Invoice':($type==='bwk_quote'?'Quotation':'Delivery Order')).' — View</h1><p class="bwk-actions"><a href="'.esc_url(get_edit_post_link($post_id)).'" class="button">Edit</a> <a href="#" class="button bwk-print-btn">Print / Save PDF</a> <span class="muted">Tip: in the browser Print dialog, turn OFF “Headers and footers” for a clean PDF.</span></p>'.$html.'</div>';
        return $html;
    }

    public function sc_invoice($a){ $a=shortcode_atts(array('id'=>0),$a); return $this->render_doc((int)$a['id'],'bwk_invoice'); }
    public function sc_quote($a){ $a=shortcode_atts(array('id'=>0),$a); return $this->render_doc((int)$a['id'],'bwk_quote'); }
    public function sc_do($a){ $a=shortcode_atts(array('id'=>0),$a); return $this->render_doc((int)$a['id'],'bwk_do'); }
}
new BWK_Lite_Accounting();
