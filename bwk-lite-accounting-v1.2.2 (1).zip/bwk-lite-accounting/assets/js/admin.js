(function($){
 function recalc($wrap){
  var subtotal = 0;
  $wrap.find('tbody tr').each(function(){
    var qty = parseFloat($(this).find('input[name*="[qty]"]').val()||0);
    var price = parseFloat($(this).find('input[name*="[price]"]').val()||0);
    var total = qty * price;
    $(this).find('input[name*="[total]"]').val(total.toFixed(2));
    subtotal += total;
  });
  var discount = parseFloat($wrap.find('input[name="bwk_totals[discount]"]').val()||0);
  var tax_rate = parseFloat($wrap.find('input[name="bwk_totals[tax_rate]"]').val()||0);
  var shipping = parseFloat($wrap.find('input[name="bwk_totals[shipping]"]').val()||0);
  var grand = subtotal - discount + ((subtotal-discount)*tax_rate/100) + shipping;
  $wrap.find('input[name="bwk_totals[subtotal]"]').val(subtotal.toFixed(2));
  $wrap.find('input[name="bwk_totals[grand]"]').val(grand.toFixed(2));
 }
 function fillFromLookup($lookup){
  var $row=$lookup.closest('tr'), val=$lookup.val()||'', parts=val.split('|').map(function(s){return s.trim();});
  if(parts.length>=4){ $row.find('input[name*="[name]"]').val(parts[2]); $row.find('input[name*="[price]"]').val((parseFloat(parts[3])||0).toFixed(2)); }
  else if(parts.length===3){ var maybe=parts[2].replace(/(MYR|RM)/gi,'').trim(); $row.find('input[name*="[name]"]').val(parts[1]); if(!isNaN(parseFloat(maybe))) $row.find('input[name*="[price]"]').val(parseFloat(maybe).toFixed(2)); }
  if(!parseFloat($row.find('input[name*="[qty]"]').val())) $row.find('input[name*="[qty]"]').val(1);
  var qty=parseFloat($row.find('input[name*="[qty]"]').val()||1), price=parseFloat($row.find('input[name*="[price]"]').val()||0);
  $row.find('input[name*="[total]"]').val((qty*price).toFixed(2)); recalc($lookup.closest('.bwk-items-wrap'));
 }
 $(document).on('click','.bwk-add',function(e){e.preventDefault(); var $t=$(this).closest('.bwk-items-wrap').find('tbody'); var i=$t.find('tr').length;
  $t.append('<tr><td><input type="text" name="bwk_items['+i+'][name]" placeholder="Item name"/><div class="bwk-pick"><input name="bwk_items['+i+'][lookup]" list="bwk-prodlist" class="bwk-lookup" placeholder="Search product (SKU/Name)"/><button class="button button-small bwk-fill">Fill</button></div></td><td><input type="number" step="0.01" name="bwk_items['+i+'][qty]" value="1"/></td><td><input type="number" step="0.01" name="bwk_items['+i+'][price]" value="0"/></td><td><input type="number" step="0.01" name="bwk_items['+i+'][total]" value="0" readonly/></td><td><button class="button bwk-del">×</button></td></tr>');
 });
 $(document).on('click','.bwk-del',function(e){e.preventDefault(); var $w=$(this).closest('.bwk-items-wrap'); $(this).closest('tr').remove(); recalc($w); });
 $(document).on('input','.bwk-items-wrap input',function(){recalc($(this).closest('.bwk-items-wrap'));});
 $(document).on('click','.bwk-fill',function(e){e.preventDefault(); fillFromLookup($(this).closest('.bwk-pick').find('.bwk-lookup'));});
 $(document).on('change blur','.bwk-lookup',function(){ fillFromLookup($(this)); });
 $(function(){ $('.bwk-items-wrap').each(function(){ recalc($(this)); }); });
 $(document).on('click','.bwk-print-btn',function(e){e.preventDefault(); window.print();});

 // Quick save (AJAX)
 $(document).on('click','#bwk-quick-save',function(e){
  e.preventDefault();
  var $btn=$(this), postId=$btn.data('postid'), nonce=$btn.data('nonce');
  var form=document.querySelector('form#post')||document.querySelector('form');
  var fd=new FormData(form); fd.append('action','bwkla_quick_save'); fd.append('post_id',postId); fd.append('_ajax_nonce',nonce);
  var $wrap=$btn.closest('.bwk-items-wrap'); if($wrap.length) recalc($wrap);
  $.ajax({url:ajaxurl,method:'POST',data:fd,processData:false,contentType:false}).done(function(r){
    if(r && r.success){ $('.bwk-save-state').text('Saved ✓').fadeIn().delay(1200).fadeOut(); if(r.data && r.data.number){$('input[name="bwk[number]"]').val(r.data.number);} }
    else{ alert('Save failed'); }
  }).fail(function(){ alert('Save failed'); });
 });
})(jQuery);