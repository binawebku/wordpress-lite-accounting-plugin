<?php
$company = isset($company)?$company:get_option('bwkla_company',array());
$company_name = esc_html( $company['name'] ?? get_bloginfo('name') );
$company_addr = nl2br( esc_html( $company['address'] ?? '' ) );
$company_phone= esc_html( $company['phone'] ?? '' );
$company_email= esc_html( $company['email'] ?? '' );
$logo = esc_url( $company['logo'] ?? '' );
$label = $post->post_type === 'bwk_invoice' ? 'INVOICE' : ( $post->post_type === 'bwk_quote' ? 'QUOTATION' : 'DELIVERY ORDER' );
$shortcode = $post->post_type === 'bwk_invoice' ? 'bwk_invoice' : ( $post->post_type === 'bwk_quote' ? 'bwk_quote' : 'bwk_do' );
$currency = $currency ?? 'MYR';
?>
<div class="bwk-print">
    <div class="no-print" style="margin-bottom:8px"><a href="#" class="button bwk-print-btn">Print / Save PDF</a></div>
    <div class="top">
        <div style="flex:1">
            <?php if ( $logo ): ?><img src="<?php echo $logo; ?>" alt="Logo" style="height:60px;border-radius:12px"/><?php endif; ?>
            <div class="muted" style="margin-top:6px"><?php echo $company_name; ?></div>
            <?php if ( $company_addr ): ?><div class="muted"><?php echo $company_addr; ?></div><?php endif; ?>
            <?php if ( $company_phone ): ?><div class="muted">Phone: <?php echo $company_phone; ?></div><?php endif; ?>
            <?php if ( $company_email ): ?><div class="muted">Email: <?php echo $company_email; ?></div><?php endif; ?>
            <h1 style="margin-top:18px"><?php echo esc_html( $label ); ?></h1>
            <div class="box" style="margin-top:8px">
                <strong>Bill To</strong>
                <div><?php echo esc_html( $customer ); ?></div>
                <?php if ( $company_c ): ?><div><?php echo esc_html( $company_c ); ?></div><?php endif; ?>
                <?php if ( $address ): ?><div><?php echo nl2br( esc_html( $address ) ); ?></div><?php endif; ?>
                <?php if ( $phone ): ?><div>Phone: <?php echo esc_html( $phone ); ?></div><?php endif; ?>
                <?php if ( $email ): ?><div>Email: <?php echo esc_html( $email ); ?></div><?php endif; ?>
            </div>
        </div>
        <div class="box" style="min-width:260px">
            <table>
                <tr><td><strong>No.</strong></td><td><?php echo esc_html( $number ); ?></td></tr>
                <tr><td><strong>Date</strong></td><td><?php echo esc_html( $date ); ?></td></tr>
                <?php if ( $due ): ?><tr><td><strong>Due</strong></td><td><?php echo esc_html( $due ); ?></td></tr><?php endif; ?>
                <tr><td><strong>Status</strong></td><td><?php echo esc_html( get_post_meta($post->ID,'_bwk_status',true) ); ?></td></tr>
            </table>
        </div>
    </div>

    <?php if ( ! empty( $notes ) ): ?>
    <div class="box" style="margin-top:12px"><strong>Remarks</strong><div><?php echo nl2br( esc_html( $notes ) ); ?></div></div>
    <?php endif; ?>

    <table>
        <thead><tr><th>#</th><th>Item</th><th style="text-align:right">Qty</th><th style="text-align:right">Unit</th><th style="text-align:right">Total</th></tr></thead>
        <tbody>
        <?php $i=1; if ( is_array( $items ) && ! empty($items) ) : foreach ( $items as $row ) : ?>
            <tr>
                <td><?php echo intval($i++); ?></td>
                <td><?php echo esc_html( $row['name'] ?? '' ); ?></td>
                <td style="text-align:right"><?php echo number_format_i18n( floatval($row['qty']??0), 2 ); ?></td>
                <td style="text-align:right"><?php echo $currency . ' ' . number_format_i18n( floatval($row['price']??0), 2 ); ?></td>
                <td style="text-align:right"><?php echo $currency . ' ' . number_format_i18n( floatval($row['total']??0), 2 ); ?></td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="5" class="muted">No items yet.</td></tr>
        <?php endif; ?>
        </tbody>
        <tfoot>
            <tr><td colspan="4" style="text-align:right">Subtotal</td><td style="text-align:right"><?php echo $currency . ' ' . number_format_i18n( $subtotal, 2 ); ?></td></tr>
            <tr><td colspan="4" style="text-align:right">Discount</td><td style="text-align:right"><?php echo $currency . ' ' . number_format_i18n( $discount, 2 ); ?></td></tr>
            <tr><td colspan="4" style="text-align:right">Tax (<?php echo number_format_i18n( $tax_rate, 2 ); ?>%)</td><td style="text-align:right"><?php echo $currency . ' ' . number_format_i18n( ($subtotal-$discount)*$tax_rate/100, 2 ); ?></td></tr>
            <tr><td colspan="4" style="text-align:right">Shipping</td><td style="text-align:right"><?php echo $currency . ' ' . number_format_i18n( $shipping, 2 ); ?></td></tr>
            <tr><td colspan="4" style="text-align:right"><strong>Grand Total</strong></td><td style="text-align:right"><strong><?php echo $currency . ' ' . number_format_i18n( $grand, 2 ); ?></strong></td></tr>
        </tfoot>
    </table>
    <p class="muted">Shortcode: [<?php echo $shortcode; ?> id="<?php echo intval($post->ID); ?>"]</p>
</div>
